package com.example.desafio4digitalhouse_firebase

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.desafio4digitalhouse_firebase.databinding.ActivityHomeBinding
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

class HomeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHomeBinding

    private val firebaseAuth by lazy {
        Firebase.auth
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)


        binding.tvTeste.text = firebaseAuth.currentUser?.email

    }
}